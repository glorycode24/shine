package com.shine.shine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShineApplicationTests {

	@Test
	void contextLoads() {
	}

}
